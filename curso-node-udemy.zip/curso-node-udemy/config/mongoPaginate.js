const options = {
  page: 1,
  limit: 10,
};

module.exports = options;
